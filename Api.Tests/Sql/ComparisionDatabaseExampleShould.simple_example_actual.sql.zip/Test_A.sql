﻿SET IDENTITY_INSERT [dbo].[Countries] ON 
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (1, N'Spain')
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (2, N'France')
GO
SET IDENTITY_INSERT [dbo].[Countries] OFF
GO
SET IDENTITY_INSERT [dbo].[Customers] ON 
GO
INSERT [dbo].[Customers] ([Id], [Name]) VALUES (1, N'AnalyticAlways')
GO
SET IDENTITY_INSERT [dbo].[Customers] OFF
GO
