﻿SET IDENTITY_INSERT [dbo].[Countries] ON 
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (1, N'Spain')
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (2, N'France')
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (3, N'United Kingdom')
GO
SET IDENTITY_INSERT [dbo].[Countries] OFF
GO
