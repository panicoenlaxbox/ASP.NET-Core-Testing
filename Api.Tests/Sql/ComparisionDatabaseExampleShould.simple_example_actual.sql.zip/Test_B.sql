﻿SET IDENTITY_INSERT [dbo].[Countries] ON 
GO
INSERT [dbo].[Countries] ([Id], [Name]) VALUES (3, N'United Kingdom')
GO
SET IDENTITY_INSERT [dbo].[Countries] OFF
GO
SET IDENTITY_INSERT [dbo].[Customers] ON 
GO
INSERT [dbo].[Customers] ([Id], [Name]) VALUES (2, N'CityTime')
GO
SET IDENTITY_INSERT [dbo].[Customers] OFF
GO
